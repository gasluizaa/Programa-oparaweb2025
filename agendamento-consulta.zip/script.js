document.getElementById('form-agendamento').addEventListener('submit', function(event) {
  event.preventDefault();

  const form = event.target;
  const formData = new FormData(form);
  const dataHora = new Date(formData.get('dataHora'));
  const agora = new Date();

  for (let [chave, valor] of formData.entries()) {
    if (chave !== 'observacao' && !valor.trim()) {
      alert(`O campo "${chave}" é obrigatório.`);
      return;
    }
  }

  if (dataHora <= agora) {
    alert("A data do agendamento deve ser posterior à data e hora atual.");
    return;
  }

  alert("Formulário enviado com sucesso!");
  form.reset();
});
